const keys = {
  kakaoKey: "d43c4d72adbf8ed5de73509787547114",
  apiKey:
    "gwtsKANRqqJdJsiXCcqhkJwe6%2Fh8L%2BcorS5ljuup0eJSs7aGoCvsqTVKDSuOTfYbEZyoQfZ2C3UmXH2R0kEFHQ%3D%3D",
};

export { keys };
